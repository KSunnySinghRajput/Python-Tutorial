def fun11():
    print("c3m2fun11")
def fun12():
    print("c3m2fun12")