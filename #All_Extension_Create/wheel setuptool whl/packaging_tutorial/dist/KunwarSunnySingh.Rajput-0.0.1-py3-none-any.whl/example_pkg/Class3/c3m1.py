def fun9():
    print("c3m1fun9")
def fun10():
    print("c3m1fun10")