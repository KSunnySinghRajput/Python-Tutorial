def fun7():
    print("c2m2fun7")
def fun8():
    print("c2m2fun8")