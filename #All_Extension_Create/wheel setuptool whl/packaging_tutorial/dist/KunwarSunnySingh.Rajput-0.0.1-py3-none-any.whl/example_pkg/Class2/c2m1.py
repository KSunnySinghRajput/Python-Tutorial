def fun5():
    print("c2m1fun5")
def fun6():
    print("c2m1fun6")