def fun3():
    print("c1m2fun3")
def fun4():
    print("c1m2fun4")