def fun1():
    print("c1m1fun1")
def fun2():
    print("c1m1fun2")